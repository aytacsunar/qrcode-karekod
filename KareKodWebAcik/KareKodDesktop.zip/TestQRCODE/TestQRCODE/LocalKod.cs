﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Imaging;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using KareKodDLL;
using Microsoft.Win32;


namespace TestQRCODE
{
    public partial class LocalKod : Form
    {
        public LocalKod()
        {
            InitializeComponent();
        }
        public Bitmap imggenel;
        public string kodlanmis = "Kodlanmis.png";
        public string kayityolu = string.Empty;
        public string kayitadi = string.Empty;
        KareKod kodcudll = new KareKod();
        private void Form1_Load(object sender, EventArgs e)
        {
            //Kullanım hakkına göre açılış
            RegistryKey yenikey = Registry.CurrentUser.OpenSubKey("Software\\KimZekiCom", true);
            if (yenikey == null)
            {
                yenikey = Registry.CurrentUser.CreateSubKey("Software\\KimZekiCom");
                yenikey.SetValue("CalismaSayisi", 500);
            }
            else
            {
                int sayi = Convert.ToInt32(yenikey.GetValue("CalismaSayisi"));
                yenikey.SetValue("CalismaSayisi", sayi - 1);

            }
            int sonadet = Convert.ToInt32(yenikey.GetValue("CalismaSayisi"));
            yenikey.Flush();
            yenikey.Close();
            if (sonadet == 0) MessageBox.Show("Bu programı son kullanısınız");
            else if (sonadet > 0) MessageBox.Show("Programı " + sonadet + " kullanım hakkınız kalmıştır");
            else
            {
                MessageBox.Show("Programı kullanım süresi dolmuştur. Program kapatılacak.");
                this.Close();
            }
            //Kullanım hakkına göre açılış :D
            //Tabların şekillendirilmesi
            tabPage1.Text = "Yazı";
            tabPage2.Text = "SMS";
            tabPage3.Text = "URL";
            tabPage4.Text = "TEL";
            tabPage5.Text = "MeCard";
            tabPage6.Text = "Ayarlar";
            //Karekod resmin ayarlarının yüklenmesi
            txtArkaPlanRenk.Text = kodcudll.ArkaRenk;
            txtKodRengi.Text = kodcudll.Renk;
            cmbBoyutu.Text = kodcudll.Boyutu.ToString();
            cmbSurumu.Text = kodcudll.Surumu.ToString();
            cmbDuzeltmeSeviyesi.Text = kodcudll.DuzeltmeSeviyesi;
        }
        public void Ayarlar()
        {
            kodcudll.ArkaRenk = txtArkaPlanRenk.Text;
            kodcudll.Renk = txtKodRengi.Text;
            kodcudll.Boyutu = Convert.ToInt32(cmbBoyutu.Text);
            kodcudll.Surumu = Convert.ToInt32(cmbSurumu.Text);
            kodcudll.DuzeltmeSeviyesi = cmbDuzeltmeSeviyesi.Text;
        }
        private void button1_Click(object sender, EventArgs e)
        {
            //   Ayarlar();
            string karekod = txtYazi.Text.Trim();
            try
            {
                Bitmap img = kodcudll.KareKodYazi(karekod);
                pictureBox1.Image = img;
                kodlanmis = kodcudll.KodlanmisYazi;
                lblUzunluk.Text = img.Size.Width.ToString() + " * " + img.Size.Height.ToString();
                lblMD5hash.Text = kodcudll.KodlanmisYazi;
            }
            catch (Exception hata)
            {
                MessageBox.Show("Hata oluştu: Sürüm seçimi düşük tutulmuş olabilir! \n" + hata.Message);
            }

            //        MessageBox.Show(kodcu.KodlanmisYazi);
            //       MessageBox.Show(kodcu.Surumu.ToString());
            //       MessageBox.Show(kodcu.DuzeltmeSeviyesi);
        }

        private void btnArkaRenkSec_Click(object sender, EventArgs e)
        {
            //   Ayarlar();
            DialogResult cevap2 = colorDialog1.ShowDialog();
            if (cevap2 == DialogResult.OK)
            {
                txtArkaPlanRenk.Text = kodcudll.HTMLKodu(colorDialog1.Color);

            }

        }

        private void btnKodRenkSec_Click(object sender, EventArgs e)
        {
            //    Ayarlar();
            DialogResult cevap2 = colorDialog1.ShowDialog();
            if (cevap2 == DialogResult.OK)
            {
                txtKodRengi.Text = kodcudll.HTMLKodu(colorDialog1.Color);

            }
        }

        private void btnYaziTemizle_Click(object sender, EventArgs e)
        {
            txtYazi.Text = string.Empty;


        }

        private void btnSMSOlustur_Click(object sender, EventArgs e)
        {
            //    Ayarlar();
            string tel = txtSMSTelNo.Text.Trim();
            string mesaj = txtSMSMesaj.Text.Trim();
            try
            {
                Bitmap img = kodcudll.KareKodKisaMesajSMS(tel, mesaj);
                pictureBox1.Image = img;
                kodlanmis = kodcudll.KodlanmisYazi;
                lblUzunluk.Text = img.Size.Width.ToString() + " * " + img.Size.Height.ToString();
                lblMD5hash.Text = kodcudll.KodlanmisYazi;
            }
            catch (Exception hata)
            {
                MessageBox.Show("Hata oluştu: Sürüm seçimi düşük tutulmuş olabilir! \n" + hata.Message);
            }

        }

        private void btnSMSTemizle_Click(object sender, EventArgs e)
        {
            txtSMSMesaj.Text = string.Empty;
            txtSMSTelNo.Text = string.Empty;
        }

        private void btnUrlKareKodOlustur_Click(object sender, EventArgs e)
        {
            //    Ayarlar();
            string url = txtUrlAdresi.Text.Trim();
            try
            {
                Bitmap img = kodcudll.KareKodWebAdresi(url);
                pictureBox1.Image = img;
                kodlanmis = kodcudll.KodlanmisYazi;
                lblUzunluk.Text = img.Size.Width.ToString() + " * " + img.Size.Height.ToString();
                lblMD5hash.Text = kodcudll.KodlanmisYazi;
            }
            catch (Exception hata)
            {
                MessageBox.Show("Hata oluştu: Sürüm seçimi düşük tutulmuş olabilir! \n" + hata.Message);
            }

        }

        private void btnTelOlustur_Click(object sender, EventArgs e)
        {
            //    Ayarlar();
            string tel = txtTelTelNumarasi.Text.Trim();
            try
            {
                Bitmap img = kodcudll.KareKodTelefon(tel);
                pictureBox1.Image = img;
                kodlanmis = kodcudll.KodlanmisYazi;
                lblUzunluk.Text = img.Size.Width.ToString() + " * " + img.Size.Height.ToString();
                lblMD5hash.Text = kodcudll.KodlanmisYazi;
            }
            catch (Exception hata)
            {
                MessageBox.Show("Hata oluştu: Sürüm seçimi düşük tutulmuş olabilir! \n" + hata.Message);
            }

        }

        private void btnTelTemizle_Click(object sender, EventArgs e)
        {
            txtTelTelNumarasi.Text = string.Empty;
        }

        private void btnMeCardOlustur_Click(object sender, EventArgs e)
        {
            //    Ayarlar();
            string adi = txtMeAdiSoyadi.Text.Trim();
            //        string takmaadi = txtMeTakmaAd.Text.Trim();
            string tel = txtMeTelefonNo.Text.Trim();
            string adresi = txtMeAdres.Text.Trim();
            string email = txtMeEposta.Text.Trim();
            string weburl = txtMeWebAdresi.Text.Trim();
            //       string not = txtMeNot.Text.Trim();
            try
            {
                Bitmap img = kodcudll.KareKodMECARD(adi, tel, adresi, email, weburl);
                pictureBox1.Image = img;
                kodlanmis = kodcudll.KodlanmisYazi;
                lblUzunluk.Text = img.Size.Width.ToString() + " * " + img.Size.Height.ToString();
                lblMD5hash.Text = kodcudll.KodlanmisYazi;
            }
            catch (Exception hata)
            {
                MessageBox.Show("Hata oluştu: Sürüm seçimi düşük tutulmuş olabilir! \n" + hata.Message);
            }

        }

        private void button2_Click(object sender, EventArgs e)
        {
            txtMeAdiSoyadi.Text = string.Empty;
            //     txtMeTakmaAd.Text = string.Empty;
            txtMeTelefonNo.Text = string.Empty;
            txtMeAdres.Text = string.Empty;
            txtMeEposta.Text = string.Empty;
            txtMeWebAdresi.Text = string.Empty;
            //    txtMeNot.Text = string.Empty;
        }

        private void button1_Click_1(object sender, EventArgs e)
        {

        }

        private void btnAyarGuncelle_Click(object sender, EventArgs e)
        {
            Ayarlar();
            MessageBox.Show("Ayarlar güncellendi!");

        }

        private void button1_Click_2(object sender, EventArgs e)
        {
            //   string dosyaadi = string.Empty;
            DialogResult cevap = saveFileDialog1.ShowDialog();
            if (cevap == DialogResult.OK)
            {
                Image resim = pictureBox1.Image;
                resim.Save(saveFileDialog1.FileName, ImageFormat.Png);
                txtKayitAdi.Text = saveFileDialog1.FileName;
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                Image resim = pictureBox1.Image;
                if (cbmd5.Checked)
                {
                    kayitadi = "AS" + kodlanmis + ".png";
                }
                else
                {
                    kayitadi = txtKayitAdi.Text.Trim();
                    kayitadi += ".png";
                }
                resim.Save(kayityolu + kayitadi, ImageFormat.Png);
            }
            catch (Exception hata)
            {
                MessageBox.Show("Geçerli bir klasör veya sürücü seçilmemiş\nDosya Adı kısmı boş bırakılmış yada .png ibaresi eklenmemiş.\n" + hata.Message);
            }

        }

        private void button4_Click(object sender, EventArgs e)
        {
            DialogResult cevap = folderBrowserDialog1.ShowDialog();
            if (cevap == DialogResult.OK)
            {
                txtKayitYolu.Text = folderBrowserDialog1.SelectedPath;
                kayityolu = folderBrowserDialog1.SelectedPath;
            }
        }

        private void cbmd5_CheckedChanged(object sender, EventArgs e)
        {
            if (cbmd5.Checked)
            {
                txtKayitAdi.Enabled = false;
            }
            else
            {
                txtKayitAdi.Enabled = true;
            }
        }

        private void btnUrlTemizle_Click(object sender, EventArgs e)
        {
            txtUrlAdresi.Text = "http://";
        }

        private void button5_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}