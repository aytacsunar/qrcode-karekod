﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TestQRCODE
{
    public partial class MaksiKareKod : Form
    {
        public MaksiKareKod()
        {
            InitializeComponent();
        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            LocalKod yeni = new LocalKod();
            yeni.MdiParent = this;
            yeni.Show();
     //       yeni.Parent = flowLayoutPanel1;
       //     yeni.Parent = toolStrip1

        }
    }
}
