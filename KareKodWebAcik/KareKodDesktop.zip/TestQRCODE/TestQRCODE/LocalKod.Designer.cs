﻿namespace TestQRCODE
{
    partial class LocalKod
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(LocalKod));
            this.btnYaziKareKod = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.btnYaziTemizle = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.txtYazi = new System.Windows.Forms.TextBox();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.btnSMSTemizle = new System.Windows.Forms.Button();
            this.btnSMSOlustur = new System.Windows.Forms.Button();
            this.txtSMSMesaj = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.txtSMSTelNo = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.btnUrlKareKodOlustur = new System.Windows.Forms.Button();
            this.btnUrlTemizle = new System.Windows.Forms.Button();
            this.txtUrlAdresi = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.btnTelOlustur = new System.Windows.Forms.Button();
            this.btnTelTemizle = new System.Windows.Forms.Button();
            this.txtTelTelNumarasi = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.label17 = new System.Windows.Forms.Label();
            this.txtMeAdres = new System.Windows.Forms.TextBox();
            this.txtMeWebAdresi = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.txtMeEposta = new System.Windows.Forms.TextBox();
            this.txtMeTelefonNo = new System.Windows.Forms.TextBox();
            this.txtMeAdiSoyadi = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.btnMeCardOlustur = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.tabPage6 = new System.Windows.Forms.TabPage();
            this.btnAyarGuncelle = new System.Windows.Forms.Button();
            this.btnKodRenkSec = new System.Windows.Forms.Button();
            this.btnArkaRenkSec = new System.Windows.Forms.Button();
            this.cmbDuzeltmeSeviyesi = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txtKodRengi = new System.Windows.Forms.TextBox();
            this.txtArkaPlanRenk = new System.Windows.Forms.TextBox();
            this.cmbSurumu = new System.Windows.Forms.ComboBox();
            this.cmbBoyutu = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
            this.colorDialog1 = new System.Windows.Forms.ColorDialog();
            this.button1 = new System.Windows.Forms.Button();
            this.cbmd5 = new System.Windows.Forms.CheckBox();
            this.folderBrowserDialog1 = new System.Windows.Forms.FolderBrowserDialog();
            this.button3 = new System.Windows.Forms.Button();
            this.txtKayitAdi = new System.Windows.Forms.TextBox();
            this.txtKayitYolu = new System.Windows.Forms.TextBox();
            this.button4 = new System.Windows.Forms.Button();
            this.label18 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label19 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.lblMD5hash = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.lblUzunluk = new System.Windows.Forms.Label();
            this.button5 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.tabPage4.SuspendLayout();
            this.tabPage5.SuspendLayout();
            this.tabPage6.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnYaziKareKod
            // 
            this.btnYaziKareKod.Location = new System.Drawing.Point(161, 331);
            this.btnYaziKareKod.Name = "btnYaziKareKod";
            this.btnYaziKareKod.Size = new System.Drawing.Size(162, 23);
            this.btnYaziKareKod.TabIndex = 0;
            this.btnYaziKareKod.Text = "KareKod Oluştur";
            this.btnYaziKareKod.UseVisualStyleBackColor = true;
            this.btnYaziKareKod.Click += new System.EventHandler(this.button1_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::TestQRCODE.Properties.Resources.logo;
            this.pictureBox1.Location = new System.Drawing.Point(356, 29);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(640, 640);
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Controls.Add(this.tabPage5);
            this.tabControl1.Controls.Add(this.tabPage6);
            this.tabControl1.ItemSize = new System.Drawing.Size(200, 30);
            this.tabControl1.Location = new System.Drawing.Point(12, 12);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(338, 398);
            this.tabControl1.TabIndex = 2;
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.Transparent;
            this.tabPage1.Controls.Add(this.btnYaziTemizle);
            this.tabPage1.Controls.Add(this.label1);
            this.tabPage1.Controls.Add(this.btnYaziKareKod);
            this.tabPage1.Controls.Add(this.txtYazi);
            this.tabPage1.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.tabPage1.Location = new System.Drawing.Point(4, 34);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(330, 360);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Tag = "Metinleriniz için geliştirilmiş en iyi KareKod oluşturucusudur.";
            this.tabPage1.Text = "Yazı";
            // 
            // btnYaziTemizle
            // 
            this.btnYaziTemizle.Location = new System.Drawing.Point(6, 331);
            this.btnYaziTemizle.Name = "btnYaziTemizle";
            this.btnYaziTemizle.Size = new System.Drawing.Size(149, 23);
            this.btnYaziTemizle.TabIndex = 2;
            this.btnYaziTemizle.Text = "Temizle";
            this.btnYaziTemizle.UseVisualStyleBackColor = true;
            this.btnYaziTemizle.Click += new System.EventHandler(this.btnYaziTemizle_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(7, 13);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(44, 17);
            this.label1.TabIndex = 1;
            this.label1.Text = "Yazı:";
            // 
            // txtYazi
            // 
            this.txtYazi.Location = new System.Drawing.Point(6, 36);
            this.txtYazi.Multiline = true;
            this.txtYazi.Name = "txtYazi";
            this.txtYazi.Size = new System.Drawing.Size(317, 289);
            this.txtYazi.TabIndex = 0;
            // 
            // tabPage2
            // 
            this.tabPage2.BackColor = System.Drawing.Color.Transparent;
            this.tabPage2.Controls.Add(this.btnSMSTemizle);
            this.tabPage2.Controls.Add(this.btnSMSOlustur);
            this.tabPage2.Controls.Add(this.txtSMSMesaj);
            this.tabPage2.Controls.Add(this.label8);
            this.tabPage2.Controls.Add(this.txtSMSTelNo);
            this.tabPage2.Controls.Add(this.label7);
            this.tabPage2.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.tabPage2.Location = new System.Drawing.Point(4, 34);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(330, 360);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "SMS";
            // 
            // btnSMSTemizle
            // 
            this.btnSMSTemizle.Location = new System.Drawing.Point(9, 249);
            this.btnSMSTemizle.Name = "btnSMSTemizle";
            this.btnSMSTemizle.Size = new System.Drawing.Size(159, 23);
            this.btnSMSTemizle.TabIndex = 5;
            this.btnSMSTemizle.Text = "Temizle";
            this.btnSMSTemizle.UseVisualStyleBackColor = true;
            this.btnSMSTemizle.Click += new System.EventHandler(this.btnSMSTemizle_Click);
            // 
            // btnSMSOlustur
            // 
            this.btnSMSOlustur.Location = new System.Drawing.Point(175, 249);
            this.btnSMSOlustur.Name = "btnSMSOlustur";
            this.btnSMSOlustur.Size = new System.Drawing.Size(149, 23);
            this.btnSMSOlustur.TabIndex = 4;
            this.btnSMSOlustur.Text = "KareKod Oluştur";
            this.btnSMSOlustur.UseVisualStyleBackColor = true;
            this.btnSMSOlustur.Click += new System.EventHandler(this.btnSMSOlustur_Click);
            // 
            // txtSMSMesaj
            // 
            this.txtSMSMesaj.Location = new System.Drawing.Point(9, 74);
            this.txtSMSMesaj.Multiline = true;
            this.txtSMSMesaj.Name = "txtSMSMesaj";
            this.txtSMSMesaj.Size = new System.Drawing.Size(315, 169);
            this.txtSMSMesaj.TabIndex = 3;
            this.txtSMSMesaj.Text = "Mesajınız";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(9, 53);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(80, 17);
            this.label8.TabIndex = 2;
            this.label8.Text = "Mesajınız:";
            // 
            // txtSMSTelNo
            // 
            this.txtSMSTelNo.Location = new System.Drawing.Point(9, 24);
            this.txtSMSTelNo.Name = "txtSMSTelNo";
            this.txtSMSTelNo.Size = new System.Drawing.Size(315, 22);
            this.txtSMSTelNo.TabIndex = 1;
            this.txtSMSTelNo.Tag = "";
            this.txtSMSTelNo.Text = "01234567890";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(6, 3);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(141, 17);
            this.label7.TabIndex = 0;
            this.label7.Text = "Telefon Numarası:";
            // 
            // tabPage3
            // 
            this.tabPage3.BackColor = System.Drawing.Color.Transparent;
            this.tabPage3.Controls.Add(this.btnUrlKareKodOlustur);
            this.tabPage3.Controls.Add(this.btnUrlTemizle);
            this.tabPage3.Controls.Add(this.txtUrlAdresi);
            this.tabPage3.Controls.Add(this.label9);
            this.tabPage3.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.tabPage3.Location = new System.Drawing.Point(4, 34);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(330, 360);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "URL";
            // 
            // btnUrlKareKodOlustur
            // 
            this.btnUrlKareKodOlustur.Location = new System.Drawing.Point(169, 56);
            this.btnUrlKareKodOlustur.Name = "btnUrlKareKodOlustur";
            this.btnUrlKareKodOlustur.Size = new System.Drawing.Size(155, 23);
            this.btnUrlKareKodOlustur.TabIndex = 3;
            this.btnUrlKareKodOlustur.Text = "KareKod Oluştur";
            this.btnUrlKareKodOlustur.UseVisualStyleBackColor = true;
            this.btnUrlKareKodOlustur.Click += new System.EventHandler(this.btnUrlKareKodOlustur_Click);
            // 
            // btnUrlTemizle
            // 
            this.btnUrlTemizle.Location = new System.Drawing.Point(7, 56);
            this.btnUrlTemizle.Name = "btnUrlTemizle";
            this.btnUrlTemizle.Size = new System.Drawing.Size(157, 23);
            this.btnUrlTemizle.TabIndex = 2;
            this.btnUrlTemizle.Text = "Temizle";
            this.btnUrlTemizle.UseVisualStyleBackColor = true;
            this.btnUrlTemizle.Click += new System.EventHandler(this.btnUrlTemizle_Click);
            // 
            // txtUrlAdresi
            // 
            this.txtUrlAdresi.Location = new System.Drawing.Point(7, 28);
            this.txtUrlAdresi.Name = "txtUrlAdresi";
            this.txtUrlAdresi.Size = new System.Drawing.Size(317, 22);
            this.txtUrlAdresi.TabIndex = 1;
            this.txtUrlAdresi.Text = "http://";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(7, 7);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(192, 17);
            this.label9.TabIndex = 0;
            this.label9.Text = "Web Site Adresi: http://...";
            // 
            // tabPage4
            // 
            this.tabPage4.BackColor = System.Drawing.Color.Transparent;
            this.tabPage4.Controls.Add(this.btnTelOlustur);
            this.tabPage4.Controls.Add(this.btnTelTemizle);
            this.tabPage4.Controls.Add(this.txtTelTelNumarasi);
            this.tabPage4.Controls.Add(this.label10);
            this.tabPage4.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.tabPage4.Location = new System.Drawing.Point(4, 34);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage4.Size = new System.Drawing.Size(330, 360);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "TEL";
            // 
            // btnTelOlustur
            // 
            this.btnTelOlustur.Location = new System.Drawing.Point(141, 55);
            this.btnTelOlustur.Name = "btnTelOlustur";
            this.btnTelOlustur.Size = new System.Drawing.Size(183, 23);
            this.btnTelOlustur.TabIndex = 3;
            this.btnTelOlustur.Text = "KareKod Oluştur";
            this.btnTelOlustur.UseVisualStyleBackColor = true;
            this.btnTelOlustur.Click += new System.EventHandler(this.btnTelOlustur_Click);
            // 
            // btnTelTemizle
            // 
            this.btnTelTemizle.Location = new System.Drawing.Point(10, 55);
            this.btnTelTemizle.Name = "btnTelTemizle";
            this.btnTelTemizle.Size = new System.Drawing.Size(129, 23);
            this.btnTelTemizle.TabIndex = 2;
            this.btnTelTemizle.Text = "Temizle";
            this.btnTelTemizle.UseVisualStyleBackColor = true;
            this.btnTelTemizle.Click += new System.EventHandler(this.btnTelTemizle_Click);
            // 
            // txtTelTelNumarasi
            // 
            this.txtTelTelNumarasi.Location = new System.Drawing.Point(10, 27);
            this.txtTelTelNumarasi.Name = "txtTelTelNumarasi";
            this.txtTelTelNumarasi.Size = new System.Drawing.Size(314, 22);
            this.txtTelTelNumarasi.TabIndex = 1;
            this.txtTelTelNumarasi.Text = "01234567890";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(7, 7);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(141, 17);
            this.label10.TabIndex = 0;
            this.label10.Text = "Telefon Numarası:";
            // 
            // tabPage5
            // 
            this.tabPage5.BackColor = System.Drawing.Color.Transparent;
            this.tabPage5.Controls.Add(this.label17);
            this.tabPage5.Controls.Add(this.txtMeAdres);
            this.tabPage5.Controls.Add(this.txtMeWebAdresi);
            this.tabPage5.Controls.Add(this.label12);
            this.tabPage5.Controls.Add(this.txtMeEposta);
            this.tabPage5.Controls.Add(this.txtMeTelefonNo);
            this.tabPage5.Controls.Add(this.txtMeAdiSoyadi);
            this.tabPage5.Controls.Add(this.label16);
            this.tabPage5.Controls.Add(this.label15);
            this.tabPage5.Controls.Add(this.label14);
            this.tabPage5.Controls.Add(this.label13);
            this.tabPage5.Controls.Add(this.label11);
            this.tabPage5.Controls.Add(this.btnMeCardOlustur);
            this.tabPage5.Controls.Add(this.button2);
            this.tabPage5.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.tabPage5.Location = new System.Drawing.Point(4, 34);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage5.Size = new System.Drawing.Size(330, 360);
            this.tabPage5.TabIndex = 4;
            this.tabPage5.Text = "MECARD";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(74, 245);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(181, 17);
            this.label17.TabIndex = 15;
            this.label17.Text = "10 ve üzeri sürümlerdir.";
            // 
            // txtMeAdres
            // 
            this.txtMeAdres.Location = new System.Drawing.Point(104, 122);
            this.txtMeAdres.Multiline = true;
            this.txtMeAdres.Name = "txtMeAdres";
            this.txtMeAdres.Size = new System.Drawing.Size(220, 79);
            this.txtMeAdres.TabIndex = 14;
            // 
            // txtMeWebAdresi
            // 
            this.txtMeWebAdresi.Location = new System.Drawing.Point(104, 93);
            this.txtMeWebAdresi.Name = "txtMeWebAdresi";
            this.txtMeWebAdresi.Size = new System.Drawing.Size(220, 22);
            this.txtMeWebAdresi.TabIndex = 13;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(38, 214);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(247, 17);
            this.label12.TabIndex = 14;
            this.label12.Text = "MeCard için tavsiye edilen sürüm";
            // 
            // txtMeEposta
            // 
            this.txtMeEposta.Location = new System.Drawing.Point(104, 64);
            this.txtMeEposta.Name = "txtMeEposta";
            this.txtMeEposta.Size = new System.Drawing.Size(220, 22);
            this.txtMeEposta.TabIndex = 12;
            // 
            // txtMeTelefonNo
            // 
            this.txtMeTelefonNo.Location = new System.Drawing.Point(104, 35);
            this.txtMeTelefonNo.Name = "txtMeTelefonNo";
            this.txtMeTelefonNo.Size = new System.Drawing.Size(220, 22);
            this.txtMeTelefonNo.TabIndex = 11;
            // 
            // txtMeAdiSoyadi
            // 
            this.txtMeAdiSoyadi.Location = new System.Drawing.Point(104, 7);
            this.txtMeAdiSoyadi.Name = "txtMeAdiSoyadi";
            this.txtMeAdiSoyadi.Size = new System.Drawing.Size(220, 22);
            this.txtMeAdiSoyadi.TabIndex = 9;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(38, 121);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(59, 17);
            this.label16.TabIndex = 7;
            this.label16.Text = "Adresi:";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(1, 95);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(96, 17);
            this.label15.TabIndex = 6;
            this.label15.Text = "Web Adresi:";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(16, 67);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(81, 17);
            this.label14.TabIndex = 5;
            this.label14.Text = "E-postası:";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(20, 37);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(77, 17);
            this.label13.TabIndex = 4;
            this.label13.Text = "Telefonu:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(7, 7);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(90, 17);
            this.label11.TabIndex = 2;
            this.label11.Text = "Adı Soyadı:";
            // 
            // btnMeCardOlustur
            // 
            this.btnMeCardOlustur.Location = new System.Drawing.Point(138, 278);
            this.btnMeCardOlustur.Name = "btnMeCardOlustur";
            this.btnMeCardOlustur.Size = new System.Drawing.Size(185, 23);
            this.btnMeCardOlustur.TabIndex = 1;
            this.btnMeCardOlustur.Text = "KareKod Oluştur";
            this.btnMeCardOlustur.UseVisualStyleBackColor = true;
            this.btnMeCardOlustur.Click += new System.EventHandler(this.btnMeCardOlustur_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(6, 278);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(126, 23);
            this.button2.TabIndex = 0;
            this.button2.Text = "Temizle";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // tabPage6
            // 
            this.tabPage6.Controls.Add(this.btnAyarGuncelle);
            this.tabPage6.Controls.Add(this.btnKodRenkSec);
            this.tabPage6.Controls.Add(this.btnArkaRenkSec);
            this.tabPage6.Controls.Add(this.cmbDuzeltmeSeviyesi);
            this.tabPage6.Controls.Add(this.label6);
            this.tabPage6.Controls.Add(this.txtKodRengi);
            this.tabPage6.Controls.Add(this.txtArkaPlanRenk);
            this.tabPage6.Controls.Add(this.cmbSurumu);
            this.tabPage6.Controls.Add(this.cmbBoyutu);
            this.tabPage6.Controls.Add(this.label5);
            this.tabPage6.Controls.Add(this.label4);
            this.tabPage6.Controls.Add(this.label3);
            this.tabPage6.Controls.Add(this.label2);
            this.tabPage6.Location = new System.Drawing.Point(4, 34);
            this.tabPage6.Name = "tabPage6";
            this.tabPage6.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage6.Size = new System.Drawing.Size(330, 360);
            this.tabPage6.TabIndex = 5;
            this.tabPage6.Text = "Ayarlar";
            this.tabPage6.UseVisualStyleBackColor = true;
            // 
            // btnAyarGuncelle
            // 
            this.btnAyarGuncelle.Location = new System.Drawing.Point(140, 160);
            this.btnAyarGuncelle.Name = "btnAyarGuncelle";
            this.btnAyarGuncelle.Size = new System.Drawing.Size(75, 23);
            this.btnAyarGuncelle.TabIndex = 13;
            this.btnAyarGuncelle.Text = "Güncelle";
            this.btnAyarGuncelle.UseVisualStyleBackColor = true;
            this.btnAyarGuncelle.Click += new System.EventHandler(this.btnAyarGuncelle_Click);
            // 
            // btnKodRenkSec
            // 
            this.btnKodRenkSec.Location = new System.Drawing.Point(268, 95);
            this.btnKodRenkSec.Name = "btnKodRenkSec";
            this.btnKodRenkSec.Size = new System.Drawing.Size(48, 23);
            this.btnKodRenkSec.TabIndex = 12;
            this.btnKodRenkSec.Text = "Seç";
            this.btnKodRenkSec.UseVisualStyleBackColor = true;
            this.btnKodRenkSec.Click += new System.EventHandler(this.btnKodRenkSec_Click);
            // 
            // btnArkaRenkSec
            // 
            this.btnArkaRenkSec.Location = new System.Drawing.Point(268, 66);
            this.btnArkaRenkSec.Name = "btnArkaRenkSec";
            this.btnArkaRenkSec.Size = new System.Drawing.Size(48, 23);
            this.btnArkaRenkSec.TabIndex = 11;
            this.btnArkaRenkSec.Text = "Seç";
            this.btnArkaRenkSec.UseVisualStyleBackColor = true;
            this.btnArkaRenkSec.Click += new System.EventHandler(this.btnArkaRenkSec_Click);
            // 
            // cmbDuzeltmeSeviyesi
            // 
            this.cmbDuzeltmeSeviyesi.FormattingEnabled = true;
            this.cmbDuzeltmeSeviyesi.Items.AddRange(new object[] {
            "L",
            "M",
            "Q",
            "H"});
            this.cmbDuzeltmeSeviyesi.Location = new System.Drawing.Point(140, 129);
            this.cmbDuzeltmeSeviyesi.Name = "cmbDuzeltmeSeviyesi";
            this.cmbDuzeltmeSeviyesi.Size = new System.Drawing.Size(121, 24);
            this.cmbDuzeltmeSeviyesi.TabIndex = 9;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(6, 132);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(127, 17);
            this.label6.TabIndex = 8;
            this.label6.Text = "Düzeltme Seviyesi:";
            // 
            // txtKodRengi
            // 
            this.txtKodRengi.Location = new System.Drawing.Point(140, 97);
            this.txtKodRengi.Name = "txtKodRengi";
            this.txtKodRengi.Size = new System.Drawing.Size(121, 22);
            this.txtKodRengi.TabIndex = 7;
            // 
            // txtArkaPlanRenk
            // 
            this.txtArkaPlanRenk.Location = new System.Drawing.Point(140, 68);
            this.txtArkaPlanRenk.Name = "txtArkaPlanRenk";
            this.txtArkaPlanRenk.Size = new System.Drawing.Size(121, 22);
            this.txtArkaPlanRenk.TabIndex = 6;
            // 
            // cmbSurumu
            // 
            this.cmbSurumu.FormattingEnabled = true;
            this.cmbSurumu.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10",
            "11",
            "12",
            "13",
            "14",
            "15",
            "16",
            "17",
            "18",
            "19",
            "20",
            "21",
            "22",
            "23",
            "24",
            "25",
            "26",
            "27",
            "28",
            "29",
            "30",
            "31",
            "32",
            "33",
            "34",
            "35",
            "36",
            "37",
            "38",
            "39",
            "40"});
            this.cmbSurumu.Location = new System.Drawing.Point(140, 37);
            this.cmbSurumu.Name = "cmbSurumu";
            this.cmbSurumu.Size = new System.Drawing.Size(121, 24);
            this.cmbSurumu.TabIndex = 5;
            // 
            // cmbBoyutu
            // 
            this.cmbBoyutu.FormattingEnabled = true;
            this.cmbBoyutu.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10"});
            this.cmbBoyutu.Location = new System.Drawing.Point(140, 6);
            this.cmbBoyutu.Name = "cmbBoyutu";
            this.cmbBoyutu.Size = new System.Drawing.Size(121, 24);
            this.cmbBoyutu.TabIndex = 4;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(55, 100);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(78, 17);
            this.label5.TabIndex = 3;
            this.label5.Text = "Kod Rengi:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(25, 71);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(109, 17);
            this.label4.TabIndex = 2;
            this.label4.Text = "Arkaplan Rengi:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(73, 40);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(61, 17);
            this.label3.TabIndex = 1;
            this.label3.Text = "Sürümü:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(74, 9);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(60, 17);
            this.label2.TabIndex = 0;
            this.label2.Text = "Boyutu: ";
            // 
            // saveFileDialog1
            // 
            this.saveFileDialog1.DefaultExt = "png";
            this.saveFileDialog1.Filter = "PNG Resmi (*.png)|*.png|BMP Resmi (*.bmp)|*.bmp|All files (*.*)|*.*";
            this.saveFileDialog1.Title = "Resmi Farklı Kaydet";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(203, 105);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(126, 50);
            this.button1.TabIndex = 3;
            this.button1.Text = "Resmi Farklı Kaydet";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click_2);
            // 
            // cbmd5
            // 
            this.cbmd5.AutoSize = true;
            this.cbmd5.Location = new System.Drawing.Point(30, 105);
            this.cbmd5.Name = "cbmd5";
            this.cbmd5.Size = new System.Drawing.Size(131, 21);
            this.cbmd5.TabIndex = 4;
            this.cbmd5.Text = "MD5Hash Modu";
            this.cbmd5.UseVisualStyleBackColor = true;
            this.cbmd5.CheckedChanged += new System.EventHandler(this.cbmd5_CheckedChanged);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(6, 132);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(191, 23);
            this.button3.TabIndex = 5;
            this.button3.Text = "KAYDET";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // txtKayitAdi
            // 
            this.txtKayitAdi.Location = new System.Drawing.Point(6, 30);
            this.txtKayitAdi.Name = "txtKayitAdi";
            this.txtKayitAdi.Size = new System.Drawing.Size(323, 22);
            this.txtKayitAdi.TabIndex = 6;
            this.txtKayitAdi.Text = "Dosyaadi.png";
            // 
            // txtKayitYolu
            // 
            this.txtKayitYolu.Enabled = false;
            this.txtKayitYolu.Location = new System.Drawing.Point(6, 58);
            this.txtKayitYolu.Name = "txtKayitYolu";
            this.txtKayitYolu.Size = new System.Drawing.Size(271, 22);
            this.txtKayitYolu.TabIndex = 7;
            this.txtKayitYolu.Text = "Mevcut Klasör";
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(283, 57);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(46, 23);
            this.button4.TabIndex = 8;
            this.button4.Text = "Seç";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(3, 85);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(293, 17);
            this.label18.TabIndex = 9;
            this.label18.Text = "Hatırlatma: Windows yüklü HDDyi seçmeyiniz!";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label18);
            this.groupBox1.Controls.Add(this.txtKayitAdi);
            this.groupBox1.Controls.Add(this.button4);
            this.groupBox1.Controls.Add(this.button1);
            this.groupBox1.Controls.Add(this.txtKayitYolu);
            this.groupBox1.Controls.Add(this.cbmd5);
            this.groupBox1.Controls.Add(this.button3);
            this.groupBox1.Location = new System.Drawing.Point(10, 509);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(340, 162);
            this.groupBox1.TabIndex = 10;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Kayıt İşlemleri";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(7, 18);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(118, 17);
            this.label19.TabIndex = 11;
            this.label19.Text = "Resmin Boyutları:";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.lblMD5hash);
            this.groupBox2.Controls.Add(this.label20);
            this.groupBox2.Controls.Add(this.lblUzunluk);
            this.groupBox2.Controls.Add(this.label19);
            this.groupBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.groupBox2.Location = new System.Drawing.Point(10, 416);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(340, 91);
            this.groupBox2.TabIndex = 12;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "KareKod Bilgileri";
            // 
            // lblMD5hash
            // 
            this.lblMD5hash.AutoSize = true;
            this.lblMD5hash.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblMD5hash.Location = new System.Drawing.Point(16, 62);
            this.lblMD5hash.Name = "lblMD5hash";
            this.lblMD5hash.Size = new System.Drawing.Size(0, 17);
            this.lblMD5hash.TabIndex = 14;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(7, 39);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(98, 17);
            this.label20.TabIndex = 13;
            this.label20.Text = "MD5Hash Adı:";
            // 
            // lblUzunluk
            // 
            this.lblUzunluk.AutoSize = true;
            this.lblUzunluk.Location = new System.Drawing.Point(131, 18);
            this.lblUzunluk.Name = "lblUzunluk";
            this.lblUzunluk.Size = new System.Drawing.Size(0, 17);
            this.lblUzunluk.TabIndex = 12;
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(921, 0);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(75, 23);
            this.button5.TabIndex = 13;
            this.button5.Text = "KAPAT";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // LocalKod
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(998, 673);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.tabControl1);
            this.Cursor = System.Windows.Forms.Cursors.Default;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "LocalKod";
            this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
            this.Text = "Maksi KareKod v.1.00.0";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            this.tabPage4.ResumeLayout(false);
            this.tabPage4.PerformLayout();
            this.tabPage5.ResumeLayout(false);
            this.tabPage5.PerformLayout();
            this.tabPage6.ResumeLayout(false);
            this.tabPage6.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnYaziKareKod;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.SaveFileDialog saveFileDialog1;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtYazi;
        private System.Windows.Forms.Button btnYaziTemizle;
        private System.Windows.Forms.TabPage tabPage6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox cmbSurumu;
        private System.Windows.Forms.ComboBox cmbBoyutu;
        private System.Windows.Forms.TextBox txtKodRengi;
        private System.Windows.Forms.TextBox txtArkaPlanRenk;
        private System.Windows.Forms.ComboBox cmbDuzeltmeSeviyesi;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ColorDialog colorDialog1;
        private System.Windows.Forms.Button btnKodRenkSec;
        private System.Windows.Forms.Button btnArkaRenkSec;
        private System.Windows.Forms.TextBox txtSMSTelNo;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtSMSMesaj;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button btnSMSOlustur;
        private System.Windows.Forms.Button btnSMSTemizle;
        private System.Windows.Forms.TextBox txtUrlAdresi;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button btnUrlKareKodOlustur;
        private System.Windows.Forms.Button btnUrlTemizle;
        private System.Windows.Forms.Button btnTelOlustur;
        private System.Windows.Forms.Button btnTelTemizle;
        private System.Windows.Forms.TextBox txtTelTelNumarasi;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Button btnMeCardOlustur;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox txtMeAdres;
        private System.Windows.Forms.TextBox txtMeWebAdresi;
        private System.Windows.Forms.TextBox txtMeEposta;
        private System.Windows.Forms.TextBox txtMeTelefonNo;
        private System.Windows.Forms.TextBox txtMeAdiSoyadi;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Button btnAyarGuncelle;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.CheckBox cbmd5;
        private System.Windows.Forms.FolderBrowserDialog folderBrowserDialog1;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.TextBox txtKayitAdi;
        private System.Windows.Forms.TextBox txtKayitYolu;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label lblUzunluk;
        private System.Windows.Forms.Label lblMD5hash;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Button button5;
    }
}

