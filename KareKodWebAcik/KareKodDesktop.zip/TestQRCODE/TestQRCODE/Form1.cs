﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Imaging;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using KareKodDLL;

namespace TestQRCODE
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            tabPage1.Text = "Hakkında";
            tabPage2.Text = "SMS";
            tabPage3.Text = "Yazı";
            tabPage1.BackColor = System.Drawing.Color.Red;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            KareKod kodcu = new KareKod();
            kodcu.Boyutu = 5;
            kodcu.Surumu = 1;
            Bitmap img = kodcu.KareKodYazi("deneme uieauiae uia eiua uiae iuaeiu ae eui eu aeui aeiua iuae uiae iuae iuae iuae uiae uiae iuae iuae uiae iua i");
            pictureBox1.Image = img;
            DialogResult cevap = saveFileDialog1.ShowDialog();
            
            if (cevap ==DialogResult.OK)
            {
                img.Save(saveFileDialog1.FileName+".png", ImageFormat.Png);
                
            }

            MessageBox.Show(kodcu.Surumu.ToString());
        }
    }
}
